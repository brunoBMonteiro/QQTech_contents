list = [1,2,3,4,5]
x = list[0]
y = list[2]
soma = x + y
print(soma)