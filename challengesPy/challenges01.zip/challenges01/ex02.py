x = 10**3
print(x)