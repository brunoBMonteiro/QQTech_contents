my_dict = {
    'a': 1,
    'b': 2,
    'c': 3,
    'd': 4,
    'e': 5
}

print(my_dict['b'])
print(my_dict['e'])