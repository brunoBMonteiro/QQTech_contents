value = '0123456789'

print(value[2:10])
print(value[0:5])
print(value[2:6])
print(value[-1:])
print(value[-2])