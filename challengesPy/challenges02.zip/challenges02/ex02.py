for numbers in range(0,102, 2):
    print(numbers)