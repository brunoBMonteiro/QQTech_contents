for numbers in range(5,21):
    print(numbers)